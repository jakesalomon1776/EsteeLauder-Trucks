<?php
$OESiteUploadDirectory = "Upload";
$OEConfWETextBox = '{"WE59fdad093a":{"InputName":"WE59fdad093a"},"WE1c3a1bd60e":{"InputName":"WE1c3a1bd60e"}}';
